﻿namespace SoftUniParking
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Car car1 = new Car("VW", "Golf II", 55, "TX6474XB");
        }
    }
}
